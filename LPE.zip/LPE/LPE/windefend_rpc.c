#include <windows.h>
#include <rpc.h>
#include <rpcndr.h>
#include "windefend_h.h"

// WD interface: {c503f532-443a-4c69-8300-ccd1fbdb3839} v1.0
// NDR transfer syntax: {8a885d04-1ceb-11c9-9fe8-08002b104860} v2.0
static const RPC_CLIENT_INTERFACE WD__RpcClientInterface = {
    sizeof(RPC_CLIENT_INTERFACE),
    {{0xc503f532,0x443a,0x4c69,{0x83,0x00,0xcc,0xd1,0xfb,0xdb,0x38,0x39}},{1,0}},
    {{0x8a885d04,0x1ceb,0x11c9,{0x9f,0xe8,0x08,0x00,0x2b,0x10,0x48,0x60}},{2,0}},
    0,0,0,0,0,0
};

RPC_STATUS Proc42_ServerMpUpdateEngineSignature(
    RPC_BINDING_HANDLE IDL_handle,
    void*    pSignatureData,
    wchar_t* pszSignatureUpdatePath,
    error_status_t* pErrorStatus)
{
    *pErrorStatus = 0;

    // NDR 2.0 wire layout for this call:
    //   [unique][in] void*     -> 4-byte referent (0x00000000 for NULL)
    //   [in, string] wchar_t*  -> 4-byte MaxCount + wchar data
    ULONG pathLen    = (ULONG)(wcslen(pszSignatureUpdatePath) + 1);
    ULONG sendBufLen = 4 + 4 + (pathLen * sizeof(WCHAR));
    sendBufLen = (sendBufLen + 3) & ~3u; // 4-byte align

    RPC_MESSAGE msg;
    ZeroMemory(&msg, sizeof(msg));
    msg.Handle                  = IDL_handle;
    msg.BufferLength            = sendBufLen;
    msg.ProcNum                 = 42;
    msg.RpcInterfaceInformation = (void*)&WD__RpcClientInterface;
    msg.DataRepresentation      = 0x00000010; // little-endian, ASCII, IEEE

    RPC_STATUS status = I_RpcGetBuffer(&msg);
    if (status != RPC_S_OK) return status;

    BYTE* p = (BYTE*)msg.Buffer;
    *(ULONG*)p = 0;       p += 4;        // NULL referent for pSignatureData
    *(ULONG*)p = pathLen; p += 4;        // MaxCount
    memcpy(p, pszSignatureUpdatePath, pathLen * sizeof(WCHAR));

    status = I_RpcSendReceive(&msg);
    if (status == RPC_S_OK && msg.BufferLength >= sizeof(DWORD))
        *pErrorStatus = *(error_status_t*)msg.Buffer;

    I_RpcFreeBuffer(&msg);
    return status;
}
