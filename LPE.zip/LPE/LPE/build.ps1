$ErrorActionPreference = "Stop"
$gcc     = "C:\msys64\mingw64\bin\gcc.exe"
$gpp     = "C:\msys64\mingw64\bin\g++.exe"
$windres = "C:\msys64\mingw64\bin\windres.exe"
$dir     = "C:\Users\windowsseclab\Documents\SignDrop_Analysis"

Set-Location $dir

Write-Host "[1/4] Compiling hid.dll from source..."
& $gcc -shared -o "$dir\hid.dll" "$dir\hid.c" -Wall -O2 -mwindows
if ($LASTEXITCODE -ne 0) { Write-Error "hid.dll compile failed"; exit 1 }
Write-Host "      hid.dll OK"

Write-Host "[2/4] Compiling resource (embeds hid.dll)..."
& $windres "$dir\SigDrop.rc" -O coff -o "$dir\SigDrop.res" --include-dir "$dir"
if ($LASTEXITCODE -ne 0) { Write-Error "windres failed"; exit 1 }
Write-Host "      SigDrop.res OK"

Write-Host "[3/4] Compiling SigDrop.exe..."
& $gpp -o "$dir\SigDrop.exe" "$dir\SigDrop.cpp" "$dir\windefend_rpc.c" "$dir\SigDrop.res" -I"$dir" -Wall -O2 -mconsole -fuse-ld=lld -lntdll -lshlwapi -lrpcrt4 -lktmw32 -lole32 -lshell32 -std=c++17
if ($LASTEXITCODE -ne 0) { Write-Error "SigDrop.exe compile failed"; exit 1 }
Write-Host "      SigDrop.exe OK"

Write-Host "[4/4] Build complete."
Get-Item "$dir\SigDrop.exe" | Select-Object Name, Length, LastWriteTime
Get-Item "$dir\hid.dll"     | Select-Object Name, Length, LastWriteTime
