#pragma once
#include <rpc.h>
#include <rpcndr.h>

#ifdef __cplusplus
extern "C" {
#endif

RPC_STATUS Proc42_ServerMpUpdateEngineSignature(
    RPC_BINDING_HANDLE IDL_handle,
    /* [unique][in] */ void* pSignatureData,
    /* [string][in] */ wchar_t* pszSignatureUpdatePath,
    /* [out] */ error_status_t* pErrorStatus
);

#ifdef __cplusplus
}
#endif
